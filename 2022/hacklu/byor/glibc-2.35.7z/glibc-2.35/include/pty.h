#ifndef _PTY_H
#include <login/pty.h>

# ifndef _ISOMAC

libc_hidden_proto (forkpty)
libc_hidden_proto (openpty)

# endif /* !_ISOMAC */
#endif
