#ifndef _PLURAL_EXP_H
#include <intl/plural-exp.h>

#ifndef _ISOMAC
extern __typeof (__gettextparse) __gettextparse attribute_hidden;
#endif /* !_ISOMAC */

#endif
