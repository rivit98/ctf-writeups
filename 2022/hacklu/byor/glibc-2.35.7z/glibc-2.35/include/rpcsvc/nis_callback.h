#ifndef _RPCSVC_NIS_CALLBACK_H
#include <nis/rpcsvc/nis_callback.h>

# ifndef _ISOMAC

libnsl_hidden_proto (xdr_obj_p)
libnsl_hidden_proto (xdr_cback_data)

# endif /* !_ISOMAC */
#endif
