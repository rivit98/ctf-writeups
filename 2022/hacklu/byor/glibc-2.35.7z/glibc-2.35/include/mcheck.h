#ifndef _MCHECK_H

#include <malloc/mcheck.h>

# ifndef _ISOMAC
# endif /* !_ISOMAC */
#endif
