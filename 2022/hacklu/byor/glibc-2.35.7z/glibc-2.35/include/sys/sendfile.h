#include <io/sys/sendfile.h>

#ifndef _ISOMAC

extern __typeof (sendfile64) __sendfile64 attribute_hidden;

#endif
