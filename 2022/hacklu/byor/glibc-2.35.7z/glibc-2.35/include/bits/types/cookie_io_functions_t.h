#include <libio/bits/types/cookie_io_functions_t.h>
