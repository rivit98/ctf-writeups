#include_next <bits/atomic_wide_counter.h>
