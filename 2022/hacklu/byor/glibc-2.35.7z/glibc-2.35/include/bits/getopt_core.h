#include <posix/bits/getopt_core.h>
