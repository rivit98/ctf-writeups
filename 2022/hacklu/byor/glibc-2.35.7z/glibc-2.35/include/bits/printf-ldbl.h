#include <stdio-common/bits/printf-ldbl.h>
