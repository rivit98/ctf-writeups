#include_next <bits/dlfcn.h>

#ifndef _ISOMAC
libc_hidden_proto (_dl_mcount_wrapper_check)
#endif
