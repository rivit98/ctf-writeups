#include <string/bits/strings_fortified.h>
