#include <string/bits/string_fortified.h>
