#ifndef _GRP_MERGE_H
#include <grp/grp-merge.h>

libc_hidden_proto (__copy_grp)
libc_hidden_proto (__merge_grp)

#endif /* _GRP_MERGE_H */
