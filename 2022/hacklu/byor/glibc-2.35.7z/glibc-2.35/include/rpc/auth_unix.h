#ifndef _RPC_AUTH_UNIX_H
#include <sunrpc/rpc/auth_unix.h>

# ifndef _ISOMAC

libc_hidden_proto (xdr_authunix_parms)

# endif /* !_ISOMAC */
#endif /* rpc/auth_unix.h */
