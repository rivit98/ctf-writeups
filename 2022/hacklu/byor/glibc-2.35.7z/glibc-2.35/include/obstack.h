#ifndef _OBSTACK_H
#include <malloc/obstack.h>

# ifndef _ISOMAC

libc_hidden_proto (_obstack_newchunk)

# endif /* !_ISOMAC */
#endif /* obstack.h */
